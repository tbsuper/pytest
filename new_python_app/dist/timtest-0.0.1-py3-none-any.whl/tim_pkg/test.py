import time

def timTest():
    print("Hello Tim.")
    time.sleep(3)
    print("Goodbye Tim.")